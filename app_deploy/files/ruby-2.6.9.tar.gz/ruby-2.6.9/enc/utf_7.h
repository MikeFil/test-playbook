#include "regenc.h"
/* dummy for unsupported, stateful encoding */
ENC_DUMMY("UTF-7");
ENC_ALIAS("CP65000", "UTF-7");


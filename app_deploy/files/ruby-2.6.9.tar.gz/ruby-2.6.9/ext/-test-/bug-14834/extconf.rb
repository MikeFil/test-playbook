# frozen_string_literal: true
create_makefile("-test-/bug_14834")
